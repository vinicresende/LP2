﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace P30481923024
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            lstbxResultados.Items.Clear();
            double[,] vendas = new double[4, 4];
            double totalMes, totalGeral;
            string valor;
            int i, j;


            totalGeral = 0;
            for (i = 0; i < 4; i++)
            {
                totalMes = 0;
                for (j = 0; j < 4; j++)
                {
                    valor = Interaction.InputBox("Total de vendas da semana " + (j + 1) + " do mês " + (i + 1) + ":", "Entrada das Notas");
                    if (double.TryParse(valor, out vendas[i, j]) && (valor != ""))
                    {
                        lstbxResultados.Items.Add("Total do mês:" + (i+1) + " Semana:" + (j+1) + " R$" + vendas[i, j].ToString("N2"));
                        totalMes += vendas[i, j];
                    }
                    else
                    {
                        MessageBox.Show("Digite valores numéricos válidos para as vendas!!!");
                        j--;
                    }
                }
                lstbxResultados.Items.Add(">> Total Mês:" + "R$" + totalMes.ToString("N2"));
                lstbxResultados.Items.Add("-------------------------------------");
                totalGeral += totalMes;
            }
            lstbxResultados.Items.Add(">> Total Geral:" + "R$" + totalGeral.ToString("N2"));
        }
    }
}
